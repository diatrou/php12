<!DOCTYPE html>

<html lang="el-GR">
	<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">

	  <title>Φόρμα E-mail</title>
	  <meta name="description" content="Φόρμα E-mail.">
	  <meta name="author" content="Εκδότης">

	  <meta property="og:title" content="Φόρμα E-mail">
	  <meta property="og:type" content="Τύπος">
	  <meta property="og:url" content="https://www.">
	  <meta property="og:description" content="Φόρμα E-mail.">
	  <meta property="og:image" content="image.png">

	  <link rel="icon" href="/favicon.ico">
	  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
	  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

	  <link rel="stylesheet" href="css/styles.css?v=1.0">

	</head>

	<body>
		<h2>Αποστολή Μηνύματος Ηλεκτρονικού Ταχυδρομείου</h2>
		<form action = "send_mail.php" method = "POST">
			<label for = "name"> Όνομα: </label><br>
			<input type = "text" id = "name" name = "name" size = "25" required> <br> <br>
			
			<label for = "email"> E-mail: </label><br>
			<input type = "email" id = "email" name = "email" size = "25" required> <br> <br>
			
			<label for = "message"> Μήνυμα: </label><br>
			<textarea id = "message" name = "message" cols = "30" rows = "5" required> </textarea> <br> <br>
			
			<input type = "submit" value = "Αποστολή">
		</form>
	  <script src="js/scripts.js"></script>
	</body>
</html>