<!DOCTYPE html>

<html lang="el-GR">
	<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">

	  <title> Αποστολή E-mail</title>
	  <meta name="description" content="Αποστολή E-mail.">
	  <meta name="author" content="Εκδότης">

	  <meta property="og:title" content="Αποστολή E-mail">
	  <meta property="og:type" content="Τύπος">
	  <meta property="og:url" content="https://www.">
	  <meta property="og:description" content="Αποστολή E-mail">
	  <meta property="og:image" content="image.png">

	  <link rel="icon" href="/favicon.ico">
	  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
	  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

	  <link rel="stylesheet" href="css/styles.css?v=1.0">

	</head>

	<body>
		<?php

			
			// Ξεκινά η δημιουργία του αλφαριθμητικού για το μήνυμα.
			$msg = "Όνομα: $_POST[name]\n";
			$msg .= "E-mail: $_POST[email]\n";
			$msg .= "Μήνυμα: $_POST[message]\n";
			
			// Ρύθμιση του mail
			$recipient = "iatroud@gmail.com";
			$subject = "Αποτελέσματα Αποστολής";
			$mailheaders = "From: ΣΑΕΚ Μεγάρων <megara@megara.gr> \n";
			$mailheaders .= "Reply-To: $_POST[email]";
			
			// Αποστολή του μηνύματος
			mail($recipient, $subject, $msg, $mailheaders);
			
			echo "<p>Η αποστολή του μηνύματος ολοκληρώθηκε από: <b>$_POST[name]</b> </p>";
			echo "<p>Από: <b>$_POST[email]</b></p>";
			echo "<p> Περιεχόμενο μηνύματος: <br>";
			echo "$_POST[message]</p>";
		?>
		<script src="js/scripts.js"></script>
	</body>
</html>